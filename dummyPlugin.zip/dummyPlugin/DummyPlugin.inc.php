<?php
import('lib.pkp.classes.plugins.GenericPlugin');

class DummyPlugin extends GenericPlugin {

    public function __construct() {
        parent::__construct();
        // Require file tambahan
        require_once($this->getPluginPath() . '/includes/extra.php');
    }

    function register($category, $path, $mainContextId = null) {
        $ojsVersion = defined('OJS_VERSION') ? OJS_VERSION : '3.x';
        if (version_compare($ojsVersion, '3.0.0', '<')) return false;

        if (parent::register($category, $path, $mainContextId)) {
            if (class_exists('HookRegistry')) {
                HookRegistry::register('TemplateManager::display', array($this, 'callbackDisplay'));
            }
            return true;
        }
        return false;
    }

    function getDisplayName() {
        return __('plugins.generic.dummy.displayName');
    }

    function getDescription() {
        return __('plugins.generic.dummy.description');
    }

    function callbackDisplay($hookName, $args) {
        $templateMgr = $args[0];
        $output =& $args[2];

        // Pakai fungsi dari extra.php
        $output .= "<p>" . sayHello() . "</p>";
        $output .= "\n<!-- Flexible Dummy Plugin Active -->\n";
        return false;
    }
}
