<?php
require_once('DummyPlugin.inc.php');
return new DummyPlugin();
